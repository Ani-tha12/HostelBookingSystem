package com.hostel.enums;

public enum RoomType {

	DORM, PRIVATE, SHARED
}

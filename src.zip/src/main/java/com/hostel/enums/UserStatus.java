package com.hostel.enums;

public enum UserStatus {

	ACTIVE, INACTIVE, PENDING, APPROVED, REJECTED
}

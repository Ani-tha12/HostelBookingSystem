package com.hostel.enums;

public enum PaymentStatus {

	PENDING, COMPLETED, FAILED, REFUNDED
}

package com.hostel.enums;

public enum BookingStatus {

	PENDING_PAYMENT, CONFIRMED, CANCELLED, REJECTED, COMPLETED
}

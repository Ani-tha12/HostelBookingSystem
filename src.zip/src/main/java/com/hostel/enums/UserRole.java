package com.hostel.enums;

public enum UserRole {

	USER, OWNER, ADMIN
}

package com.hostel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostelBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostelBookingSystemApplication.class, args);
	}

}
